# Temperature-Converter
In this project it accepts the input from the user and convert celsius to fahrenheit and fahrenheit to celsius
